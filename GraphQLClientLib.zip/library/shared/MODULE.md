#Module shared
the GraphQLClientLib module is the main module in this library.<br>
GraphQLClientLib is a GraphQL Client library that help developers consume GraphQL apis easily.

#Package com.machinesTalk.graphqlclientlib
the main package of the library.

#important
How to add the library to your project
This application have 2 classes:
<br>
-the MainActivity class
<br>
-the GestureDetector class :

this class alow users to detect all the actions applied by the user on the screen

<h5> This application use sceneform as an external library</h5>
so to integrate this library safely please follow the steps <a href="https://fr.acervolima.com/comment-creer-une-application-android-de-realite-augmentee-simple/">here</a>